﻿using System;
using System.Runtime.CompilerServices;

namespace BoxOfT
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
        }
    }
}
